// const Filters = require('./filters');

// const ImageFilters = [
//   {
//     heading: 'Stay with your current supplier',
//     subheading: 'Save up to',
//     message: 'We can get you another deal with your current supplier and handle the switch for you',
//     filter: Filters.currentCompany,
//     showSubHeading: false,
//     isActive: true,
//   },
//   {
//     heading: 'Switch to a big name supplier',
//     subheading: 'Save up to',
//     message: 'We can narrow your results to only show the big companies you may recognise',
//     filter: Filters.bigCompany,
//     showSubHeading: false,
//     isActive: true,
//   },
//   {
//     heading: 'Choose from our full range',
//     subheading: 'Save up to',
//     message: 'Choose from any of our deals for a simple, straightforward switch',
//     filter: Filters.none,
//     showSubHeading: false,
//     isActive: true,
//   }
// ];

// module.exports = ('ImageFilters', ImageFilters);


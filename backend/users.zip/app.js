const path = require('path');
const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const app = express();
var expressSanitizer = require('express-sanitizer');

const userRoutes = require('./users/users.routes');
const userUrl = "/api/users";

const companyRoutes = require('./companies/companies.routes');
const companyUrl = "/api/companies";

const productRoutes = require('./products/products.routes');
const productUrl = "/api/products";

const pageRoutes = require('./pages/pages.routes');
const pageUrl = "/api/pages";

const customerRoutes = require('./customers/customers.routes');
const customerUrl = "/api/customers";

app.use("/assets", express.static(path.join("assets")));

mongoose.set('useFindAndModify', false);

mongoose
  .connect(
    "mongodb+srv://admin:" + process.env.MONGO_ATLAS_PW + "@cluster0-oriea.mongodb.net/cc-money?retryWrites=true",
    { useNewUrlParser: true }
  )
  .then(() => {
    console.log("Connected to database");
  })
  .catch(() => {
    console.log("Connection failed");
  });

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(expressSanitizer());

app.use((req, res, next) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept, Authorization"
  );
  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PATCH, PUT, DELETE, OPTIONS"
  );
  next();
});

app.use(userUrl, userRoutes);
app.use(companyUrl, companyRoutes);
app.use(productUrl, productRoutes);
app.use(pageUrl, pageRoutes);
app.use(customerUrl, customerRoutes);
module.exports = app;

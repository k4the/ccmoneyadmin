const Filters = {
  currentCompany: 'currentCompany',
  bigCompany: 'isBig',
  none: 'none'
}

module.exports = ('Filters', Filters);
